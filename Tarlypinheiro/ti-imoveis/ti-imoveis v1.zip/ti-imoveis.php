<?php
/**
 * Plugin Name: T Imóveis
 * Plugin URI:  https://tarlypinheiroimoveis.com.br
 * Description: Sistema completo de imóveis — CPT, galeria, CRM de leads e SEO avançado.
 * Version:     1.0.0
 * Author:      Tarly Pinheiro Imóveis
 * Text Domain: ti-imoveis
 * License:     GPL-2.0+
 */
defined('ABSPATH') || exit;

define('TI_VER',      '1.0.0');
define('TI_PATH',     plugin_dir_path(__FILE__));
define('TI_URL',      plugin_dir_url(__FILE__));
define('TI_PHONE',    '5562995219521');
define('TI_PHONE_BR', '(62) 9 9521-9521');
define('TI_CRECI',    'CRECI 105224');

foreach (['cpt', 'meta-boxes', 'leads', 'admin-pages', 'frontend', 'ajax', 'sitemap'] as $m) {
    require_once TI_PATH . "includes/{$m}.php";
}

register_activation_hook(__FILE__, 'ti_activate');
register_deactivation_hook(__FILE__, static function () { flush_rewrite_rules(); });

function ti_activate(): void {
    ti_register_cpt();
    flush_rewrite_rules();
    ti_install_db();

    if ( ! get_page_by_path('imoveis') ) {
        wp_insert_post([
            'post_title'   => 'Imóveis',
            'post_name'    => 'imoveis',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '[ti_resultados]',
        ]);
    }
}

function ti_install_db(): void {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ti_leads (
        id          BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
        nome        VARCHAR(120)     NOT NULL,
        telefone    VARCHAR(25)      NOT NULL,
        email       VARCHAR(120)     DEFAULT '',
        imovel_id   BIGINT           DEFAULT 0,
        imovel_nome VARCHAR(300)     DEFAULT '',
        status      ENUM('lead','contato','negociacao','fechamento','noshow') DEFAULT 'lead',
        descricao   TEXT,
        enviou_docs TINYINT(1)       DEFAULT 0,
        indicou     VARCHAR(255)     DEFAULT '',
        created_at  DATETIME         DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME         DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_status (status),
        KEY idx_imovel (imovel_id)
    ) {$c};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
