<?php
defined('ABSPATH') || exit;

// ── Funções de acesso à tabela de leads ───────────────────────────────────────

function ti_save_lead(array $data): int|false {
    global $wpdb;
    $ok = $wpdb->insert(
        $wpdb->prefix . 'ti_leads',
        [
            'nome'        => sanitize_text_field($data['nome'] ?? ''),
            'telefone'    => sanitize_text_field($data['telefone'] ?? ''),
            'email'       => sanitize_email($data['email'] ?? ''),
            'imovel_id'   => (int)($data['imovel_id'] ?? 0),
            'imovel_nome' => sanitize_text_field($data['imovel_nome'] ?? ''),
            'status'      => 'lead',
        ],
        ['%s','%s','%s','%d','%s','%s']
    );
    return $ok ? $wpdb->insert_id : false;
}

function ti_get_leads(string $status = ''): array {
    global $wpdb;
    $table = $wpdb->prefix . 'ti_leads';
    if ($status) {
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM $table WHERE status = %s ORDER BY created_at DESC", $status)
        ) ?: [];
    }
    return $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC") ?: [];
}

function ti_get_leads_grouped(): array {
    $statuses = ['lead','contato','negociacao','fechamento','noshow'];
    $result   = [];
    foreach ($statuses as $s) {
        $result[$s] = ti_get_leads($s);
    }
    return $result;
}

function ti_update_lead_status(int $id, string $status): bool {
    global $wpdb;
    $valid = ['lead','contato','negociacao','fechamento','noshow'];
    if ( ! in_array($status, $valid) ) return false;
    return (bool) $wpdb->update(
        $wpdb->prefix . 'ti_leads',
        ['status' => $status, 'updated_at' => current_time('mysql')],
        ['id' => $id],
        ['%s','%s'],
        ['%d']
    );
}

function ti_update_lead_info(int $id, array $data): bool {
    global $wpdb;
    $set = [];
    $fmt = [];
    if ( isset($data['descricao']) ) { $set['descricao'] = sanitize_textarea_field($data['descricao']); $fmt[] = '%s'; }
    if ( isset($data['enviou_docs']) ) { $set['enviou_docs'] = (int)$data['enviou_docs']; $fmt[] = '%d'; }
    if ( isset($data['indicou']) ) { $set['indicou'] = sanitize_text_field($data['indicou']); $fmt[] = '%s'; }
    if ( empty($set) ) return false;
    $set['updated_at'] = current_time('mysql'); $fmt[] = '%s';
    return (bool) $wpdb->update($wpdb->prefix . 'ti_leads', $set, ['id' => $id], $fmt, ['%d']);
}

function ti_get_lead(int $id): ?object {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ti_leads WHERE id = %d", $id));
}

function ti_leads_count_by_status(): array {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT status, COUNT(*) AS total FROM {$wpdb->prefix}ti_leads GROUP BY status");
    $map  = [];
    foreach ($rows as $r) $map[$r->status] = (int)$r->total;
    return $map;
}
