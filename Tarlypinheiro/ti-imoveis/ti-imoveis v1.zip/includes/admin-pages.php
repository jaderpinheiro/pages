<?php
defined('ABSPATH') || exit;

// ── Menu principal ────────────────────────────────────────────────────────────
add_action('admin_menu', function () {
    add_menu_page(
        'T Imóveis', 'T Imóveis', 'manage_options',
        'ti-dashboard', 'ti_page_dashboard',
        'dashicons-building', 25
    );
    add_submenu_page('ti-dashboard', 'Dashboard',       'Dashboard',       'manage_options', 'ti-dashboard',  'ti_page_dashboard');
    add_submenu_page('ti-dashboard', 'Todos os Imóveis','Todos os Imóveis','manage_options', 'edit.php?post_type=imovel', '');
    add_submenu_page('ti-dashboard', 'Adicionar Imóvel','Adicionar Imóvel','manage_options', 'post-new.php?post_type=imovel', '');
    add_submenu_page('ti-dashboard', 'Leads / CRM',     'Leads / CRM',     'manage_options', 'ti-leads',      'ti_page_leads');
});

// ── Admin assets ──────────────────────────────────────────────────────────────
add_action('admin_enqueue_scripts', function ($hook) {
    if ( ! in_array($hook, ['toplevel_page_ti-dashboard', 'timoveis_page_ti-leads']) &&
         ! str_contains($hook, 'ti-') ) {
        // Também carrega na edição do CPT
        if ( ! str_contains($hook, 'imovel') ) return;
    }
    wp_enqueue_media();
    wp_enqueue_style('ti-admin',  TI_URL . 'assets/css/admin.css',  [], TI_VER);
    wp_enqueue_script('ti-admin', TI_URL . 'assets/js/admin.js', ['jquery'], TI_VER, true);
    wp_localize_script('ti-admin', 'ti_admin', [
        'ajax'  => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ti_admin_nonce'),
    ]);
});

// ── Página: Dashboard ─────────────────────────────────────────────────────────
function ti_page_dashboard(): void {
    $total     = wp_count_posts('imovel')->publish ?? 0;
    $counts    = ti_leads_count_by_status();
    $total_leads = array_sum($counts);
    $recentes  = get_posts(['post_type'=>'imovel','posts_per_page'=>5,'post_status'=>'publish']);
    ?>
    <div class="wrap ti-admin-wrap">
      <h1>T Imóveis — Dashboard</h1>
      <div class="ti-stats-grid">
        <div class="ti-stat-card">
          <div class="ti-stat-num"><?= esc_html($total) ?></div>
          <div class="ti-stat-label">Imóveis Publicados</div>
        </div>
        <div class="ti-stat-card">
          <div class="ti-stat-num"><?= esc_html($total_leads) ?></div>
          <div class="ti-stat-label">Total de Leads</div>
        </div>
        <div class="ti-stat-card ti-stat-gold">
          <div class="ti-stat-num"><?= esc_html($counts['negociacao'] ?? 0) ?></div>
          <div class="ti-stat-label">Em Negociação</div>
        </div>
        <div class="ti-stat-card ti-stat-green">
          <div class="ti-stat-num"><?= esc_html($counts['fechamento'] ?? 0) ?></div>
          <div class="ti-stat-label">Fechamentos</div>
        </div>
      </div>

      <div class="ti-section-title">Imóveis recentes</div>
      <table class="ti-table">
        <thead><tr><th>Imóvel</th><th>Tipo</th><th>Preço</th><th>Status</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($recentes as $p):
            $tipo  = get_the_terms($p->ID, 'tipo_imovel');
            $preco = get_post_meta($p->ID, '_ti_valor_venda', true) ?: get_post_meta($p->ID, '_ti_valor_aluguel', true);
            $st    = get_post_meta($p->ID, '_ti_status', true) ?: 'disponivel';
            $stMap = ['disponivel'=>'<span class="ti-badge green">Disponível</span>','vendido'=>'<span class="ti-badge red">Vendido</span>','alugado'=>'<span class="ti-badge gold">Alugado</span>','reservado'=>'<span class="ti-badge blue">Reservado</span>'];
          ?>
          <tr>
            <td><strong><?= esc_html($p->post_title) ?></strong></td>
            <td><?= $tipo ? esc_html(wp_list_pluck($tipo,'name')[0]) : '—' ?></td>
            <td><?= $preco ? 'R$ ' . number_format((float)$preco,0,',','.') : '—' ?></td>
            <td><?= $stMap[$st] ?? esc_html($st) ?></td>
            <td><a href="<?= esc_url(get_edit_post_link($p->ID)) ?>" class="ti-btn-sm">Editar</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <p><a href="<?= admin_url('edit.php?post_type=imovel') ?>" class="ti-btn">Ver todos os imóveis →</a></p>
    </div>
    <?php
}

// ── Página: Leads / CRM ───────────────────────────────────────────────────────
function ti_page_leads(): void {
    $grouped = ti_get_leads_grouped();
    $cols    = [
        'lead'        => ['label' => 'Leads',       'color' => '#0D1B2A'],
        'contato'     => ['label' => 'Em Contato',  'color' => '#2563EB'],
        'negociacao'  => ['label' => 'Negociação',  'color' => '#D97706'],
        'fechamento'  => ['label' => 'Fechamento',  'color' => '#059669'],
        'noshow'      => ['label' => 'No-show',     'color' => '#DC2626'],
    ];
    ?>
    <div class="wrap ti-admin-wrap">
      <h1>Leads / CRM</h1>
      <p class="ti-hint">Arraste os cartões entre as colunas para atualizar o status. Clique em um cartão para ver detalhes.</p>

      <div class="ti-kanban">
        <?php foreach ($cols as $status => $cfg): ?>
        <div class="ti-kanban-col" data-status="<?= $status ?>">
          <div class="ti-col-header" style="border-color:<?= esc_attr($cfg['color']) ?>;">
            <span class="ti-col-title"><?= esc_html($cfg['label']) ?></span>
            <span class="ti-col-count" id="count-<?= $status ?>"><?= count($grouped[$status]) ?></span>
          </div>
          <div class="ti-col-body" id="col-<?= $status ?>" ondragover="event.preventDefault()" ondrop="tiDrop(event,'<?= $status ?>')">
            <?php foreach ($grouped[$status] as $lead): ?>
            <div class="ti-lead-card" draggable="true"
                 data-id="<?= (int)$lead->id ?>"
                 ondragstart="tiDragStart(event,<?= (int)$lead->id ?>)"
                 onclick="tiOpenLead(<?= (int)$lead->id ?>)">
              <div class="ti-lead-name"><?= esc_html($lead->nome) ?></div>
              <div class="ti-lead-tel">📞 <?= esc_html($lead->telefone) ?></div>
              <?php if ($lead->imovel_nome): ?>
              <div class="ti-lead-imovel">🏠 <?= esc_html(wp_trim_words($lead->imovel_nome, 6)) ?></div>
              <?php endif; ?>
              <div class="ti-lead-date"><?= esc_html(date_i18n('d/m/Y H:i', strtotime($lead->created_at))) ?></div>
              <?php if ($lead->enviou_docs): ?><span class="ti-lead-tag">📄 Docs enviados</span><?php endif; ?>
              <?php if ($lead->indicou): ?><span class="ti-lead-tag">👥 Indicou</span><?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- MODAL LEAD DETAIL -->
    <div id="tiLeadModal" class="ti-modal" style="display:none;">
      <div class="ti-modal-box">
        <button class="ti-modal-close" onclick="document.getElementById('tiLeadModal').style.display='none'">✕</button>
        <h2 id="tiLeadModalTitle">Lead</h2>
        <div class="ti-modal-grid">
          <div><strong>Nome:</strong> <span id="tl-nome"></span></div>
          <div><strong>Telefone:</strong> <span id="tl-tel"></span></div>
          <div><strong>E-mail:</strong> <span id="tl-email"></span></div>
          <div><strong>Imóvel:</strong> <span id="tl-imovel"></span></div>
          <div><strong>Data:</strong> <span id="tl-date"></span></div>
          <div><strong>Status:</strong> <span id="tl-status"></span></div>
        </div>
        <hr>
        <label><strong>Descrição / Observações</strong>
          <textarea id="tl-desc" rows="4" style="width:100%;margin-top:6px;padding:8px;border:1px solid #ddd;border-radius:6px;"></textarea>
        </label>
        <div style="display:flex;gap:16px;align-items:center;margin:12px 0;">
          <label><input type="checkbox" id="tl-docs"> Enviou documentação</label>
          <label>Indicou alguém: <input type="text" id="tl-indicou" style="padding:6px 10px;border:1px solid #ddd;border-radius:6px;margin-left:8px;width:200px;"></label>
        </div>
        <button class="ti-btn" onclick="tiSaveLead()">💾 Salvar alterações</button>
        <a id="tl-wa-btn" href="#" target="_blank" class="ti-btn ti-btn-green" style="text-decoration:none;">💬 Abrir no WhatsApp</a>
      </div>
    </div>

    <script>
    var _tiCurrentLeadId = null;
    var _tiLeadsData = <?php
        $all = [];
        foreach ($grouped as $leads) foreach ($leads as $l) $all[$l->id] = $l;
        echo wp_json_encode($all, JSON_UNESCAPED_UNICODE);
    ?>;

    function tiDragStart(e, id) { e.dataTransfer.setData('leadId', id); }
    function tiDrop(e, status) {
        e.preventDefault();
        var id = e.dataTransfer.getData('leadId');
        fetch(ti_admin.ajax, {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body: new URLSearchParams({action:'ti_move_lead', nonce:ti_admin.nonce, id, status})
        }).then(r=>r.json()).then(function(res){
            if(res.success) location.reload();
        });
    }
    function tiOpenLead(id) {
        _tiCurrentLeadId = id;
        var l = _tiLeadsData[id];
        if(!l) return;
        document.getElementById('tiLeadModalTitle').textContent = 'Lead: ' + l.nome;
        document.getElementById('tl-nome').textContent    = l.nome;
        document.getElementById('tl-tel').textContent     = l.telefone;
        document.getElementById('tl-email').textContent   = l.email || '—';
        document.getElementById('tl-imovel').textContent  = l.imovel_nome || '—';
        document.getElementById('tl-date').textContent    = l.created_at;
        document.getElementById('tl-status').textContent  = l.status;
        document.getElementById('tl-desc').value          = l.descricao || '';
        document.getElementById('tl-docs').checked        = l.enviou_docs == 1;
        document.getElementById('tl-indicou').value       = l.indicou || '';
        document.getElementById('tl-wa-btn').href         = 'https://wa.me/' + l.telefone.replace(/\D/g,'');
        document.getElementById('tiLeadModal').style.display = 'flex';
    }
    function tiSaveLead() {
        if(!_tiCurrentLeadId) return;
        fetch(ti_admin.ajax, {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body: new URLSearchParams({
                action:'ti_update_lead', nonce:ti_admin.nonce,
                id: _tiCurrentLeadId,
                descricao: document.getElementById('tl-desc').value,
                enviou_docs: document.getElementById('tl-docs').checked ? 1 : 0,
                indicou: document.getElementById('tl-indicou').value
            })
        }).then(r=>r.json()).then(function(res){
            if(res.success) { document.getElementById('tiLeadModal').style.display='none'; location.reload(); }
            else alert('Erro ao salvar.');
        });
    }
    </script>
    <?php
}
