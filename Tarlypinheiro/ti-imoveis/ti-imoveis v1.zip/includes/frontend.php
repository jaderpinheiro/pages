<?php
defined('ABSPATH') || exit;

// ── Template override (standalone — sem dependência de tema) ──────────────────
add_filter('template_include', function ($tpl) {
    if ( is_singular('imovel') ) {
        $custom = TI_PATH . 'templates/single-imovel.php';
        return file_exists($custom) ? $custom : $tpl;
    }
    if ( is_page('imoveis') ) {
        $custom = TI_PATH . 'templates/search-imoveis.php';
        return file_exists($custom) ? $custom : $tpl;
    }
    return $tpl;
});

// ── Enqueue scripts ───────────────────────────────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('ti-public', TI_URL . 'assets/css/public.css', [], TI_VER);
    wp_enqueue_script('ti-public', TI_URL . 'assets/js/public.js', [], TI_VER, true);
    wp_localize_script('ti-public', 'ti_ajax', [
        'url'   => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ti_public_nonce'),
        'phone' => TI_PHONE,
        'creci' => TI_CRECI,
    ]);
});

// ── Shortcode fallback [ti_resultados] ────────────────────────────────────────
add_shortcode('ti_resultados', function ($atts) {
    ob_start();
    include TI_PATH . 'templates/search-imoveis.php';
    return ob_get_clean();
});

// ── SEO meta tags para imóveis ────────────────────────────────────────────────
add_action('wp_head', function () {
    if ( ! is_singular('imovel') ) return;
    $id    = get_the_ID();
    $title = get_the_title($id);
    $desc  = get_post_meta($id, '_ti_descricao', true);
    $thumb = get_the_post_thumbnail_url($id, 'large');
    $price = get_post_meta($id, '_ti_valor_venda', true) ?: get_post_meta($id, '_ti_valor_aluguel', true);
    $bairro= get_post_meta($id, '_ti_bairro', true);
    $cidade= get_post_meta($id, '_ti_cidade', true) ?: 'Goiânia';
    $excerpt = $desc ? wp_trim_words($desc, 30) : "{$title} em {$bairro}, {$cidade}. " . TI_CRECI;

    printf('<meta name="description" content="%s">'."\n", esc_attr($excerpt));
    printf('<meta property="og:title" content="%s | Tarly Pinheiro Imóveis">'."\n", esc_attr($title));
    printf('<meta property="og:description" content="%s">'."\n", esc_attr($excerpt));
    if ($thumb) printf('<meta property="og:image" content="%s">'."\n", esc_url($thumb));
    printf('<meta property="og:type" content="product">'."\n");

    // Schema RealEstateListing
    $schema = [
        '@context'    => 'https://schema.org',
        '@type'       => 'RealEstateListing',
        'name'        => $title,
        'description' => $excerpt,
        'url'         => get_permalink($id),
        'address'     => [
            '@type'           => 'PostalAddress',
            'streetAddress'   => get_post_meta($id, '_ti_rua', true) . ', ' . get_post_meta($id, '_ti_numero', true),
            'addressLocality' => $cidade,
            'addressRegion'   => get_post_meta($id, '_ti_estado', true) ?: 'GO',
            'addressCountry'  => 'BR',
        ],
    ];
    if ($price) $schema['price'] = 'R$ ' . number_format((float)$price, 2, ',', '.');
    if ($thumb) $schema['image'] = $thumb;
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}, 5);

// ── Helper: obter dados do imóvel como array ──────────────────────────────────
function ti_get_imovel_data(int $id): array {
    $meta = function($k) use ($id) { return get_post_meta($id, $k, true); };
    $gallery_ids = array_filter(explode(',', $meta('_ti_gallery') ?: ''));

    $negocio  = get_the_terms($id, 'negocio');
    $tipo     = get_the_terms($id, 'tipo_imovel');
    $bairro_t = get_the_terms($id, 'bairro_imovel');

    return [
        'id'           => $id,
        'title'        => get_the_title($id),
        'excerpt'      => get_the_excerpt($id),
        'permalink'    => get_permalink($id),
        'thumb'        => get_the_post_thumbnail_url($id, 'large') ?: '',
        'gallery'      => array_map(fn($gid) => wp_get_attachment_image_url((int)$gid, 'large'), $gallery_ids),
        'metragem'     => $meta('_ti_metragem'),
        'quartos'      => $meta('_ti_quartos'),
        'suites'       => $meta('_ti_suites'),
        'banheiros'    => $meta('_ti_banheiros'),
        'vagas'        => $meta('_ti_vagas'),
        'andar'        => $meta('_ti_andar'),
        'valor_venda'  => $meta('_ti_valor_venda'),
        'valor_aluguel'=> $meta('_ti_valor_aluguel'),
        'valor_cond'   => $meta('_ti_valor_condominio'),
        'valor_iptu'   => $meta('_ti_valor_iptu'),
        'descricao'    => $meta('_ti_descricao'),
        'rua'          => $meta('_ti_rua'),
        'numero'       => $meta('_ti_numero'),
        'bairro'       => $meta('_ti_bairro'),
        'cidade'       => $meta('_ti_cidade') ?: 'Goiânia',
        'estado'       => $meta('_ti_estado') ?: 'GO',
        'cod_anunc'    => $meta('_ti_codigo_anunciante'),
        'cod_viva'     => $meta('_ti_codigo_vivareal'),
        'status'       => $meta('_ti_status') ?: 'disponivel',
        'destaque'     => $meta('_ti_destaque'),
        'aceita_anim'  => $meta('_ti_aceita_animais'),
        'lavanderia'   => $meta('_ti_lavanderia'),
        'area_serv'    => $meta('_ti_area_servico'),
        'piscina'      => $meta('_ti_piscina'),
        'academia'     => $meta('_ti_academia'),
        'negocio'      => $negocio ? wp_list_pluck($negocio, 'name')[0] : '',
        'tipo'         => $tipo    ? wp_list_pluck($tipo,    'name')[0] : '',
        'bairro_tax'   => $bairro_t? wp_list_pluck($bairro_t,'name')[0] : '',
        'publicado'    => $meta('_ti_publicado_em') ?: get_the_date('d \d\e F \d\e Y', $id),
    ];
}

// ── Helper: formatar preço ────────────────────────────────────────────────────
function ti_fmt_price(string $val): string {
    if ( ! $val ) return '—';
    return 'R$ ' . number_format((float)$val, 0, ',', '.');
}

// ── Helper: WP_Query para busca ───────────────────────────────────────────────
function ti_query_imoveis(array $args = []): WP_Query {
    $defaults = [
        'post_type'      => 'imovel',
        'post_status'    => 'publish',
        'posts_per_page' => 12,
        'paged'          => max(1, get_query_var('paged')),
    ];
    $tax_query = [];

    if ( ! empty($args['negocio']) ) {
        $tax_query[] = ['taxonomy' => 'negocio', 'field' => 'name', 'terms' => $args['negocio']];
    }
    if ( ! empty($args['tipo']) ) {
        $tax_query[] = ['taxonomy' => 'tipo_imovel', 'field' => 'name', 'terms' => $args['tipo']];
    }
    if ( count($tax_query) > 1 ) $tax_query['relation'] = 'AND';
    if ( $tax_query ) $defaults['tax_query'] = $tax_query;

    if ( ! empty($args['busca']) ) $defaults['s'] = $args['busca'];

    // Filtro de faixa de preço via meta_query
    if ( ! empty($args['faixa']) ) {
        $faixa = $args['faixa'];
        $mq    = ['relation' => 'OR'];
        if ( str_contains($faixa, 'Até') ) {
            preg_match('/[\d.]+/', $faixa, $m);
            $max = (int)str_replace('.','', $m[0] ?? '999999');
            $mq[] = ['key' => '_ti_valor_venda',   'value' => $max, 'type' => 'NUMERIC', 'compare' => '<='];
            $mq[] = ['key' => '_ti_valor_aluguel',  'value' => $max, 'type' => 'NUMERIC', 'compare' => '<='];
        } elseif ( str_contains($faixa, 'Acima') ) {
            $mq[] = ['key' => '_ti_valor_venda',   'value' => 1000000, 'type' => 'NUMERIC', 'compare' => '>='];
        }
        if ( count($mq) > 1 ) $defaults['meta_query'] = $mq;
    }

    return new WP_Query($defaults);
}
