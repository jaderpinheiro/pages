/* T Imóveis — Public JS */
(function () {
  'use strict';

  // ── Lead Popup ─────────────────────────────────────────────────────────────
  var _leadId = null;

  window.openLeadPopup = function (imovelId) {
    _leadId = imovelId || null;
    var info = document.getElementById('leadImovelInfo');
    if (info) info.style.display = _leadId ? 'block' : 'none';
    var popup = document.getElementById('leadPopup');
    if (popup) {
      popup.classList.add('active');
      var nomeEl = document.getElementById('leadNome');
      if (nomeEl) nomeEl.focus();
    }
  };

  window.closeLeadPopup = function () {
    var popup = document.getElementById('leadPopup');
    if (popup) popup.classList.remove('active');
  };

  window.submitLead = function () {
    var nome  = (document.getElementById('leadNome') || {}).value || '';
    var tel   = (document.getElementById('leadTelefone') || {}).value || '';
    var email = (document.getElementById('leadEmail') || {}).value || '';
    nome = nome.trim(); tel = tel.trim(); email = email.trim();
    if (!nome || !tel) {
      var target = document.getElementById(nome ? 'leadTelefone' : 'leadNome');
      if (target) { target.style.borderColor = '#DC2626'; target.focus(); }
      return;
    }

    // Salvar via AJAX se WP disponível
    if (typeof ti_ajax !== 'undefined') {
      var body = new URLSearchParams({
        action: 'ti_save_lead',
        nonce: ti_ajax.nonce,
        nome: nome, telefone: tel, email: email,
        imovel_id: _leadId || 0,
        imovel_nome: ''
      });
      fetch(ti_ajax.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
      });
    }

    var phone = (typeof ti_ajax !== 'undefined' && ti_ajax.phone) ? ti_ajax.phone : '5562995219521';
    var msg   = 'Olá Tarly! Me chamo ' + nome + '. Encontrei seu site e gostaria de saber sobre imóveis. Meu celular: ' + tel;
    window.closeLeadPopup();
    window.open('https://wa.me/' + phone + '?text=' + encodeURIComponent(msg), '_blank');
  };

  // Fechar popup com ESC
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') window.closeLeadPopup();
  });

  // ── Nav Scroll ─────────────────────────────────────────────────────────────
  window.addEventListener('scroll', function () {
    var nav = document.getElementById('mainNav');
    if (nav) nav.classList.toggle('scrolled', window.scrollY > 40);
  });

  // ── Reveal on Scroll ───────────────────────────────────────────────────────
  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  function initReveal() {
    document.querySelectorAll('.reveal').forEach(function (el) { observer.observe(el); });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setTimeout(initReveal, 100); });
  } else {
    setTimeout(initReveal, 100);
  }

})();
