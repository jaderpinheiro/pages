/* T Imóveis — Admin JS */
jQuery(function ($) {
  // Kanban drag highlight
  document.querySelectorAll('.ti-col-body').forEach(function (col) {
    col.addEventListener('dragover', function (e) {
      e.preventDefault();
      col.style.background = '#EEF2FF';
    });
    col.addEventListener('dragleave', function () {
      col.style.background = '';
    });
    col.addEventListener('drop', function () {
      col.style.background = '';
    });
  });

  document.querySelectorAll('.ti-lead-card').forEach(function (card) {
    card.addEventListener('dragstart', function () { card.classList.add('dragging'); });
    card.addEventListener('dragend',   function () { card.classList.remove('dragging'); });
  });

  // Fechar modal com ESC
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      var m = document.getElementById('tiLeadModal');
      if (m) m.style.display = 'none';
    }
  });
});
