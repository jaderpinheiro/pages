<?php
defined('ABSPATH') || exit;
if ( ! have_posts() ) { wp_redirect(home_url('/404')); exit; }
the_post();

$d = ti_get_imovel_data(get_the_ID());
$seo_title = $d['title'];
$seo_desc  = wp_trim_words($d['descricao'] ?: $d['title'], 30);
$seo_image = $d['thumb'];

include TI_PATH . 'templates/partials/head.php';
include TI_PATH . 'templates/partials/topbar-nav.php';

$fotos = array_filter(array_merge($d['thumb'] ? [$d['thumb']] : [], $d['gallery']));
$negocio_label = $d['negocio'] === 'Venda' ? 'Venda' : ($d['negocio'] === 'Aluguel' ? 'Aluguel' : 'Lançamento');
$price_label   = $d['negocio'] === 'Aluguel' ? 'Aluguel/mês' : 'Venda';
$price_val     = $d['negocio'] === 'Aluguel' ? $d['valor_aluguel'] : $d['valor_venda'];
?>

<!-- GALERIA HERO -->
<div class="detail-hero" id="detail-hero">
  <a href="<?= home_url('/imoveis/') ?>" class="detail-back">← Voltar</a>
  <?php if ($fotos): ?>
    <div class="gallery-slides" id="gallerySlides">
      <?php foreach ($fotos as $i => $url): ?>
      <img src="<?= esc_url($url) ?>" alt="<?= esc_attr($d['title']) ?>" class="gallery-slide<?= $i === 0 ? ' active' : '' ?>"
           style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:<?= $i===0?'1':'0' ?>;transition:opacity 0.5s;">
      <?php endforeach; ?>
    </div>
    <?php if (count($fotos) > 1): ?>
    <div class="detail-gallery-strip" id="gallery-dots">
      <?php foreach ($fotos as $i => $_): ?>
      <div class="gallery-dot<?= $i===0?' active':'' ?>" onclick="goToSlide(<?= $i ?>)"></div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  <?php else: ?>
    <div style="width:100%;height:100%;background:linear-gradient(135deg,var(--blue-light),var(--cream));display:flex;align-items:center;justify-content:center;">
      <svg width="64" height="64" fill="none" viewBox="0 0 24 24" stroke="rgba(100,130,160,0.3)" stroke-width="1"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
    </div>
  <?php endif; ?>
</div>

<!-- DETAIL BODY -->
<div class="detail-body">
  <div class="detail-main">
    <div class="detail-badge-row">
      <span class="card-badge<?= $d['destaque'] ? ' gold' : '' ?>"><?= esc_html($negocio_label) ?></span>
      <?php if ($d['tipo']): ?><span class="card-badge" style="background:var(--blue-light);color:var(--slate);"><?= esc_html($d['tipo']) ?></span><?php endif; ?>
      <?php if ($d['status'] !== 'disponivel'): ?>
        <span class="card-badge" style="background:<?= $d['status']==='vendido'?'#DC2626':($d['status']==='alugado'?'#D97706':'#2563EB') ?>;color:white;">
          <?= ucfirst($d['status']) ?>
        </span>
      <?php endif; ?>
    </div>
    <h1 class="detail-title"><?= esc_html($d['title']) ?></h1>
    <p class="detail-address">📍 <?= esc_html(trim("{$d['rua']}, {$d['numero']} — {$d['bairro']}, {$d['cidade']} - {$d['estado']}", ' ,—')) ?></p>

    <!-- CARACTERÍSTICAS -->
    <div class="detail-features">
      <?php if ($d['metragem']): ?>
      <div class="detail-feat"><div class="detail-feat-icon">📐</div>
        <div class="detail-feat-val"><?= esc_html($d['metragem']) ?> m²</div>
        <div class="detail-feat-label">Área total</div></div>
      <?php endif; ?>
      <?php if ($d['quartos']): ?>
      <div class="detail-feat"><div class="detail-feat-icon">🛏</div>
        <div class="detail-feat-val"><?= esc_html($d['quartos']) ?></div>
        <div class="detail-feat-label">Quartos<?= $d['suites'] ? ' (' . esc_html($d['suites']) . ' suítes)' : '' ?></div></div>
      <?php endif; ?>
      <?php if ($d['banheiros']): ?>
      <div class="detail-feat"><div class="detail-feat-icon">🚿</div>
        <div class="detail-feat-val"><?= esc_html($d['banheiros']) ?></div>
        <div class="detail-feat-label">Banheiros</div></div>
      <?php endif; ?>
      <?php if ($d['vagas']): ?>
      <div class="detail-feat"><div class="detail-feat-icon">🚗</div>
        <div class="detail-feat-val"><?= esc_html($d['vagas']) ?></div>
        <div class="detail-feat-label">Vagas</div></div>
      <?php endif; ?>
    </div>

    <!-- COMODIDADES -->
    <?php $amens = [];
    foreach (['aceita_anim'=>'Aceita Animais','lavanderia'=>'Lavanderia','area_serv'=>'Área de Serviço','piscina'=>'Piscina','academia'=>'Academia'] as $k=>$l) {
        if ($d[$k]) $amens[] = $l;
    }
    if ($amens): ?>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:28px;">
      <?php foreach ($amens as $a): ?>
      <span style="background:var(--blue-light);padding:6px 14px;border-radius:20px;font-size:12px;color:var(--slate);">✓ <?= esc_html($a) ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- DESCRIÇÃO -->
    <?php if ($d['descricao']): ?>
    <h2 class="detail-desc-title">Sobre o Imóvel</h2>
    <div class="detail-desc"><?= nl2br(esc_html($d['descricao'])) ?></div>
    <?php endif; ?>

    <!-- CÓDIGOS / PUBLICAÇÃO -->
    <div style="margin-top:28px;padding:16px;background:var(--blue-light);border-radius:12px;font-size:13px;color:var(--slate-light);">
      <?php if ($d['cod_anunc']): ?><span>Código do anunciante: <strong><?= esc_html($d['cod_anunc']) ?></strong></span><?php endif; ?>
      <?php if ($d['cod_viva']): ?><span style="margin-left:16px;">Viva Real: <strong><?= esc_html($d['cod_viva']) ?></strong></span><?php endif; ?>
      <p style="margin-top:8px;">Anúncio publicado em <?= esc_html($d['publicado']) ?>. <br>
      <small>⚠️ Valores de condomínio e IPTU podem sofrer alteração. Sujeito a confirmação de disponibilidade.</small></p>
    </div>

    <!-- SEGURANÇA -->
    <div style="margin-top:20px;padding:16px 20px;border:1px solid var(--border);border-radius:12px;">
      <strong style="color:var(--navy);font-size:14px;">🔒 Segurança em primeiro lugar!</strong>
      <ul style="margin-top:8px;padding-left:20px;font-size:13px;color:var(--slate);line-height:1.8;">
        <li>Nunca transfira dinheiro sem visitar o imóvel e verificar a documentação</li>
        <li>Não compartilhe seus dados pessoais fora deste canal</li>
        <li>Caso alguma informação seja incorreta, entre em contato conosco</li>
      </ul>
    </div>
  </div>

  <!-- SIDEBAR -->
  <div class="detail-sidebar">
    <div class="price-card">
      <?php if ($price_val): ?>
      <div class="price-label"><?= esc_html($price_label) ?></div>
      <div class="price-big"><?= ti_fmt_price($price_val) ?></div>
      <?php if ($d['valor_cond'] || $d['valor_iptu']): ?>
      <div class="price-cond">
        <?= $d['valor_cond'] ? 'Cond. ' . ti_fmt_price($d['valor_cond']) : '' ?>
        <?= $d['valor_iptu'] ? ' · IPTU ' . ti_fmt_price($d['valor_iptu']) . '/mês' : '' ?>
      </div>
      <?php endif; ?>
      <?php else: ?>
      <div class="price-label">Valor</div>
      <div class="price-big" style="font-size:22px;">Consulte-nos</div>
      <?php endif; ?>

      <div style="margin:20px 0 10px;">
        <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">📞 <?= TI_PHONE_BR ?></div>
        <div style="font-size:11px;color:var(--text-muted);"><?= TI_CRECI ?></div>
      </div>

      <button class="btn-wa-detail" onclick="openLeadPopup(<?= (int)$d['id'] ?>)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/></svg>
        Falar com Tarly
      </button>
      <button class="btn-share-detail" onclick="shareImovelWA(<?= (int)$d['id'] ?>, '<?= esc_js($d['title']) ?>', '<?= esc_js(ti_fmt_price($price_val)) ?>', '<?= esc_url(get_permalink()) ?>')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
        Compartilhar
      </button>
    </div>
  </div>
</div>

<script>
// Gallery slider
var _slides = document.querySelectorAll('.gallery-slide');
var _dots   = document.querySelectorAll('.gallery-dot');
var _current = 0;
function goToSlide(i) {
  if(_slides.length < 2) return;
  _slides[_current].style.opacity = '0';
  _dots[_current] && _dots[_current].classList.remove('active');
  _current = i;
  _slides[_current].style.opacity = '1';
  _dots[_current] && _dots[_current].classList.add('active');
}
if(_slides.length > 1) {
  setInterval(function(){ goToSlide((_current + 1) % _slides.length); }, 5000);
}

// Lead popup para WP
var ti_imovel_wp = {
  id: <?= (int)$d['id'] ?>,
  title: <?= wp_json_encode($d['title']) ?>,
  price: <?= wp_json_encode(ti_fmt_price($price_val)) ?>
};

function shareImovelWA(id, title, price, url) {
  var msg = '🏠 *'+title+'*\n💰 '+price+'\n\nVeja mais: '+url+'\n\n*Tarly Pinheiro Imóveis | <?= TI_CRECI ?>*\n📱 <?= TI_PHONE_BR ?>';
  window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank');
}

// Nav scroll
window.addEventListener('scroll', function(){
  var nav = document.getElementById('mainNav');
  if(nav) nav.classList.toggle('scrolled', window.scrollY > 40);
});
</script>

<?php include TI_PATH . 'templates/partials/footer.php'; ?>
