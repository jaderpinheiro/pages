<?php
/**
 * Gerenciamento de paginas WordPress - criar ou atualizar.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cria ou atualiza uma pagina WordPress com base no slug.
 * O HTML completo e salvo sem filtragem KSES e entregue
 * diretamente ao navegador (sem tema do WordPress).
 *
 * @param string $slug  Slug da pagina.
 * @param string $title Titulo da pagina.
 * @param string $html     Conteudo HTML completo.
 * @param string $base_url URL base dos assets (ex.: https://projeto.vercel.app/). Opcional.
 * @return array{page_id: int, slug: string, status: string}|WP_Error
 */
function isa_upsert_page( string $slug, string $title, string $html, string $base_url = '' ): array|WP_Error {
    $existing = isa_get_page_by_slug( $slug );

    $post_data = [
        'post_title'   => $title,
        'post_content' => $html,
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_name'    => $slug,
    ];

    // Remove filtros KSES para preservar <style>, <script> e HTML completo.
    kses_remove_filters();

    if ( $existing ) {
        $post_data['ID'] = $existing->ID;
    }

    // wp_insert_post/wp_update_post aplicam wp_unslash(): sem wp_slash() as
    // barras invertidas do HTML (regex, strings em <script>) seriam removidas.
    $post_data = wp_slash( $post_data );

    if ( $existing ) {
        $page_id         = wp_update_post( $post_data, true );
        $op_status       = 'updated';
    } else {
        $page_id   = wp_insert_post( $post_data, true );
        $op_status = 'created';
    }

    kses_init_filters();

    if ( is_wp_error( $page_id ) ) {
        return $page_id;
    }

    $html_hash = hash( 'sha256', $html );

    update_post_meta( $page_id, '_isa_html_hash',   $html_hash );
    update_post_meta( $page_id, '_isa_last_deploy', gmdate( 'c' ) );
    update_post_meta( $page_id, '_isa_full_page',   '1' );

    if ( '' !== $base_url ) {
        update_post_meta( $page_id, '_isa_base_url', $base_url );
    }

    return [
        'page_id' => $page_id,
        'slug'    => $slug,
        'status'  => $op_status,
    ];
}

/**
 * Entrega o HTML completo diretamente, sem tema do WordPress,
 * para paginas marcadas com _isa_full_page.
 */
add_action( 'template_redirect', 'isa_maybe_render_full_page', 1 );

function isa_maybe_render_full_page(): void {
    if ( ! is_page() ) {
        return;
    }

    $post_id = get_queried_object_id();

    if ( ! get_post_meta( $post_id, '_isa_full_page', true ) ) {
        return;
    }

    $post = get_post( $post_id );

    if ( ! $post ) {
        return;
    }

    $html     = $post->post_content;
    $base_url = isa_get_base_url( $post_id );

    if ( '' !== $base_url ) {
        $html = isa_absolutize_urls( $html, $base_url );
    }

    // Envia o HTML sem passar por nenhum filtro do WordPress.
    header( 'Content-Type: text/html; charset=UTF-8' );
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput
    exit;
}

/**
 * URL base dos assets: meta da pagina (enviada no deploy) ou a constante
 * INLINE_SYNC_ASSET_BASE do wp-config.php. Sempre termina com "/".
 *
 * @param int $post_id
 * @return string
 */
function isa_get_base_url( int $post_id ): string {
    $base = (string) get_post_meta( $post_id, '_isa_base_url', true );

    if ( '' === $base && defined( 'INLINE_SYNC_ASSET_BASE' ) ) {
        $base = (string) INLINE_SYNC_ASSET_BASE;
    }

    return '' === $base ? '' : trailingslashit( $base );
}

/**
 * Converte caminhos relativos (assets/..., ./x, /x) em URLs absolutas
 * apontando para $base_url. Sem isso, "assets/css/main.css" servido em
 * https://site.com/slug/ vira https://site.com/slug/assets/css/main.css (404).
 *
 * Ignora URLs absolutas, ancoras (#), data:, mailto:, tel: e javascript:.
 *
 * @param string $html
 * @param string $base_url Terminada em "/".
 * @return string
 */
function isa_absolutize_urls( string $html, string $base_url ): string {
    $resolve = static function ( string $url ) use ( $base_url ): string {
        $url = trim( $url );

        if ( '' === $url || preg_match( '~^([a-z][a-z0-9+.-]*:|//|#)~i', $url ) ) {
            return $url;
        }

        if ( '/' === $url[0] ) {
            $parts = wp_parse_url( $base_url );
            return $parts['scheme'] . '://' . $parts['host']
                . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' ) . $url;
        }

        return $base_url . preg_replace( '~^\./~', '', $url );
    };

    // src, href, poster, data-src, action
    $html = preg_replace_callback(
        '~(\s(?:src|href|poster|data-src|action)\s*=\s*)(["\'])(.*?)\2~is',
        static fn( $m ) => $m[1] . $m[2] . $resolve( $m[3] ) . $m[2],
        $html
    );

    // srcset / imagesrcset: lista "url 1x, url 2x"
    $html = preg_replace_callback(
        '~(\s(?:srcset|imagesrcset)\s*=\s*)(["\'])(.*?)\2~is',
        static function ( $m ) use ( $resolve ) {
            $items = array_map(
                static function ( $item ) use ( $resolve ) {
                    $parts = preg_split( '~\s+~', trim( $item ), 2 );
                    return $resolve( $parts[0] ) . ( isset( $parts[1] ) ? ' ' . $parts[1] : '' );
                },
                explode( ',', $m[3] )
            );
            return $m[1] . $m[2] . implode( ', ', $items ) . $m[2];
        },
        $html
    );

    // url(...) em <style> e atributos style (url(#id) do SVG e preservado)
    $html = preg_replace_callback(
        '~url\(\s*(["\']?)([^"\')]+)\1\s*\)~i',
        static fn( $m ) => 'url(' . $m[1] . $resolve( $m[2] ) . $m[1] . ')',
        $html
    );

    return $html;
}

/**
 * Busca uma pagina pelo slug (post_name).
 *
 * @param string $slug
 * @return WP_Post|null
 */
function isa_get_page_by_slug( string $slug ): ?WP_Post {
    $pages = get_posts( [
        'post_type'      => 'page',
        'name'           => $slug,
        'post_status'    => [ 'publish', 'draft', 'private' ],
        'posts_per_page' => 1,
        'no_found_rows'  => true,
    ] );

    return $pages[0] ?? null;
}
